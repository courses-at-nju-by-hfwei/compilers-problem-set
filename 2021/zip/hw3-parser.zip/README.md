# hw-3

- tools for writing `cfg` and drawing `tree` (LaTeX, online)