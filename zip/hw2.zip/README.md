# hw-2

- tools for writing `regex` and drawing `automata` (LaTeX, online)